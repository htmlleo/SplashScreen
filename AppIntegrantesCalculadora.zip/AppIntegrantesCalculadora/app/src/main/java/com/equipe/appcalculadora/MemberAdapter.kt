package com.equipe.appcalculadora

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MemberAdapter(private val memberList: List<Member>, private val listener: OnMemberClickListener) :
    RecyclerView.Adapter<MemberAdapter.MemberViewHolder>() {

    interface OnMemberClickListener {
        fun onMemberClick(member: Member)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MemberViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_member, parent, false)
        return MemberViewHolder(view)
    }

    override fun onBindViewHolder(holder: MemberViewHolder, position: Int) {
        val member = memberList[position]
        holder.memberName.text = member.name
        holder.memberRole.text = member.role
        holder.itemView.setOnClickListener { listener.onMemberClick(member) }
    }

    override fun getItemCount(): Int {
        return memberList.size
    }

    class MemberViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val memberName: TextView = itemView.findViewById(R.id.member_name)
        val memberRole: TextView = itemView.findViewById(R.id.member_role)
    }
}
