package com.equipe.appcalculadora

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar

class CalculatorFragment : Fragment() {

    private lateinit var grade1EditText: EditText
    private lateinit var grade2EditText: EditText
    private lateinit var grade3EditText: EditText
    private lateinit var calculateButton: Button
    private lateinit var resetButton: Button

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_calculator, container, false)

        grade1EditText = view.findViewById(R.id.edit_text_grade1)
        grade2EditText = view.findViewById(R.id.edit_text_grade2)
        grade3EditText = view.findViewById(R.id.edit_text_grade3)
        calculateButton = view.findViewById(R.id.button_calculate)
        resetButton = view.findViewById(R.id.button_reset)

        calculateButton.setOnClickListener { calculateAverage() }
        resetButton.setOnClickListener { resetFields() }

        return view
    }

    private fun calculateAverage() {
        val grade1Str = grade1EditText.text.toString()
        val grade2Str = grade2EditText.text.toString()
        val grade3Str = grade3EditText.text.toString()

        if (grade1Str.isEmpty() || grade2Str.isEmpty() || grade3Str.isEmpty()) {
            Snackbar.make(requireView(), "Por favor, preencha todas as notas.", Snackbar.LENGTH_SHORT).show()
            return
        }

        try {
            val grade1 = grade1Str.toDouble()
            val grade2 = grade2Str.toDouble()
            val grade3 = grade3Str.toDouble()

            val average = (grade1 + grade2 + grade3) / 3
            val result = when {
                average < 4 -> "Reprovado direto"
                average >= 4 && average < 6 -> "Em recuperação"
                else -> "Aprovado"
            }

            Snackbar.make(requireView(), "Média: %.2f - %s".format(average, result), Snackbar.LENGTH_LONG).show()

        } catch (e: NumberFormatException) {
            Snackbar.make(requireView(), "Por favor, insira notas válidas.", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun resetFields() {
        grade1EditText.setText("")
        grade2EditText.setText("")
        grade3EditText.setText("")
        Snackbar.make(requireView(), "Campos resetados!", Snackbar.LENGTH_SHORT).show()
    }
}
