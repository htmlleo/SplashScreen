package com.equipe.appcalculadora

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MemberListFragment : Fragment(), MemberAdapter.OnMemberClickListener {

    private lateinit var memberRecyclerView: RecyclerView
    private lateinit var memberAdapter: MemberAdapter
    private lateinit var memberList: MutableList<Member>

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_member_list, container, false)

        memberRecyclerView = view.findViewById(R.id.member_recycler_view)
        memberRecyclerView.layoutManager = LinearLayoutManager(context)

        memberList = ArrayList()
        // Adicionar membros da equipe
        memberList.add(Member("Leonardo Estevão Alves", "R.A: 00250458-1", "Estudante de desenvolvimento Android."))
        memberList.add(Member("Vinicius Correia De Andrade", "R.A: 251953-1", "Estudante de desenvolvimento Android."))

        memberAdapter = MemberAdapter(memberList, this)
        memberRecyclerView.adapter = memberAdapter

        return view
    }

    override fun onMemberClick(member: Member) {
        val intent = Intent(activity, MemberDetailActivity::class.java)
        intent.putExtra("member", member)
        startActivity(intent)
    }
}
