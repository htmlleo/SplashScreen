package com.equipe.appcalculadora

import java.io.Serializable

data class Member(
    val name: String,
    val role: String,
    val description: String
) : Serializable
