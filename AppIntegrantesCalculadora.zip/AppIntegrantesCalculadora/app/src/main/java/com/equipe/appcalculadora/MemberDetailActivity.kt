package com.equipe.appcalculadora

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MemberDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_member_detail)

        val detailMemberName: TextView = findViewById(R.id.detail_member_name)
        val detailMemberRole: TextView = findViewById(R.id.detail_member_role)
        val detailMemberDescription: TextView = findViewById(R.id.detail_member_description)

        val member = intent.getSerializableExtra("member") as? Member

        member?.let {
            detailMemberName.text = it.name
            detailMemberRole.text = it.role
            detailMemberDescription.text = it.description
        }
    }
}
